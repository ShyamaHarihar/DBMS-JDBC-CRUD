package dbconn;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
public class crud1 {		  
			public static void main(String[] args) 
			{
			    String url = "jdbc:mysql://localhost:3306/mysql?useSSL=false";
			    String username = "shyama";
			    String passwd = "root";
			    Connection connect = null;
			    Statement st = null;
			    try 
			{
			connect = DriverManager.getConnection(url, username, passwd);
			st = connect.createStatement();
			st.executeUpdate("create table customer(customer_id varchar(20),account_no varchar(20),gender varchar(20),customer_phone_no varchar(20),address varchar(20),products_purchased varchar(20));");
			
			
			System.out.println("Table created");
			}catch(SQLException e) 
			{
			e.printStackTrace();
			}finally
			{
			      try {
			        if (st != null) {
			          st.close();
			        }
			        if (connect!= null) {
			          connect.close();
			        }
			      } catch (Exception e) {
			        e.printStackTrace();
			      }
}}}
