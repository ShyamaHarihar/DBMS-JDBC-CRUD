package dbconn;
import java.sql.*;
public class drop {

	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/mysql?useSSL=false";
	    String username = "shyama";
	    String passwd = "root";
	    Connection connect = null;
	    Statement st = null;
	    try 
	{
	connect = DriverManager.getConnection(url, username, passwd);
	st = connect.createStatement();
	st.executeUpdate("drop table customer;");
    System.out.println("Table has been dropped");
	}
	    catch(SQLException e) 
	{
	e.printStackTrace();
	}

	}

}
