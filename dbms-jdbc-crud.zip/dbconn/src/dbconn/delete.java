package dbconn;
import java.sql.*;
public class delete {

	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/mysql?useSSL=false";
	    String username = "shyama";
	    String passwd = "root";
	    Connection connect = null;
	    Statement st = null;
	    try 
		{
		connect = DriverManager.getConnection(url, username, passwd);
		st=connect.createStatement();
		String query="Update customer set gender='male' where gender='female';";
	    st.executeUpdate(query);
	    System.out.print("Update done");
	    
		}
	    catch(Exception e)
	    {
	    	System.out.print(e.getMessage());
	    }

	}

}
